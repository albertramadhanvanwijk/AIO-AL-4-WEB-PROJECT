// Candidate
const candidates = [
    {
        id: '1',
        image: 'assets/images/users/avatar-2.jpg',
        name: 'Nancy Martino',
        designation: 'Creative Designer',
        location: 'Escondido,California'
    },
    {
        id: '2',
        image: 'assets/images/users/avatar-3.jpg',
        name: 'Glen Matney',
        designation: 'Marketing Director',
        location: 'Escondido,California'
    },
    {
        id: '3',
        image: 'assets/images/users/avatar-10.jpg',
        name: 'Alexis Clarke',
        designation: 'Product Manager',
        location: 'Escondido,California'
    },
    {
        id: '4',
        image: 'assets/images/users/avatar-8.jpg',
        name: 'James Price',
        designation: 'Product Designer',
        location: 'Escondido,California'
    },
    {
        id: '5',
        image: 'assets/images/users/avatar-5.jpg',
        name: 'Michael Morris',
        designation: 'Full Stack Developer',
        location: 'Escondido,California'
    }
]
export { candidates }