export interface servicesModel {
    icon: string;
    title: string;
    content: string;
  }
  