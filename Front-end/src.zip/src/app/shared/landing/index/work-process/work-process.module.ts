export interface ProcessModel {
    icon: string;
    title: string;
    content: string;
  }
  