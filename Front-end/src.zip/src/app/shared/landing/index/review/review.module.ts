export interface clientLogoModel {
    content: string;
    title: string;
    subTitle: string;
  }
  