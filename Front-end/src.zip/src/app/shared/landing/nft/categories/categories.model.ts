export interface clientLogoModel {
  images: Array<{
    image?: Array<{
      img?: string;
    }>;
  }>;
}
