export interface featuresModel {
    image: string;
    title: string;
    content: string;
  }
  