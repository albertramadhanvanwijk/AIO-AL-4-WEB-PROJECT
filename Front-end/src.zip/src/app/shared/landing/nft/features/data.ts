const featuresData = [
    {
      image: 'assets/images/nft/wallet.png',
      title: 'Set up your wallet',
      content: 'You have to choose whether to use a hot wallet a cold wallet.',
    },
    {
      image: 'assets/images/nft/money.png',
      title: 'Create your collection',
      content: 'Create a collection in Opensea and give it a proper art.',
    }, 
    {
      image: 'assets/images/nft/add.png',
      title: `Add your NFT's`,
      content: 'Go to your profile icon and top right corner creation page.',
    }, 
    {
      image: 'assets/images/nft/sell.png',
      title: `Sell Your NFT's`,
      content: 'Create a collection in Opensea and give Add items and art.',
    },    
  ];
  
  export { featuresData };
  