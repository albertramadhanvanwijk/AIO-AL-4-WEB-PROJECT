export interface walletModel {
    image: string;
    title: string;
    content: string;
    btn_color: string;
  }
  