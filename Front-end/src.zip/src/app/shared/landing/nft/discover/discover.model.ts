export interface discoverModel {
  id: number;
  cardImg: string;
  author: string;
  title: string;
  img: string;
  likes: string;
  price: string;
  category: string;
  isIcon?: any;
}
  