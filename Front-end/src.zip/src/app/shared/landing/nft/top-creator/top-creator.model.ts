export interface creatorModel {
  id: number;
  img: string;
  title: string;
  price: string;
}
  