// Chart data
export interface ChartType {
    series?: any;
    chart?: any;
    dataLabels?: any;
    plotOptions?: any;
    colors?: any;
}