import { Component } from '@angular/core';

@Component({
  selector: 'app-wi-preparasi',
  templateUrl: './wi-preparasi.component.html',
  styleUrls: ['./wi-preparasi.component.scss']
})
export class WiPreparasiComponent {

}
