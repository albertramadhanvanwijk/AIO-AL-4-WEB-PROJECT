import { Component } from '@angular/core';

@Component({
  selector: 'app-wi-ibf',
  templateUrl: './wi-ibf.component.html',
  styleUrls: ['./wi-ibf.component.scss']
})
export class WiIBFComponent {

}
