import { Component } from '@angular/core';

@Component({
  selector: 'app-wi-packing',
  templateUrl: './wi-packing.component.html',
  styleUrls: ['./wi-packing.component.scss']
})
export class WiPackingComponent {

}
